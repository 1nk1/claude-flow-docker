# ⚡ Quick Start - MCP in 3 Commands

## Step 1: Start Docker (30 seconds)

```bash
cd /path/to/claude-flow-docker
make start
```

**Verify:**
```bash
docker ps | grep claude-flow-alpha
```

## Step 2: Connect Project (30 seconds)

```bash
./connect-mcp.sh ~/projects/your-project
```

**Output:**
```
✅ Container is running
✅ MCP configuration created
✅ MCP connection test passed
```

## Step 3: Use Claude Code (30 seconds)

```bash
cd ~/projects/your-project
claude
```

**Test in Claude:**
```
Show me the claude-flow swarm status
```

## ✅ Success Check

```bash
claude mcp list
```

Expected:
```
claude-flow: docker exec -i claude-flow-alpha claude-flow mcp start - ✓ Connected
```

## 🎯 First Commands

**Create Swarm:**
```
Create a mesh swarm with 3 agents
```

**Memory:**
```
Store in memory: project = "awesome-app"
```

**Performance:**
```
Show performance report
```

## 📚 Full Documentation

- **Quick Start:** [QUICKSTART_MCP.md](docs/QUICKSTART_MCP.md)
- **Complete Guide:** [MCP_CONNECTION.md](docs/MCP_CONNECTION.md)
- **Main README:** [MCP_README.md](MCP_README.md)

## 🐛 Troubleshooting

**Container not running?**
```bash
docker-compose up -d
```

**Connection failed?**
```bash
docker restart claude-flow-alpha
claude mcp list
```

---

**That's it! You're ready! 🚀**
