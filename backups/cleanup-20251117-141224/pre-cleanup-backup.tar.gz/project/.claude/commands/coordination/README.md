# Coordination Commands

Commands for coordination operations in Claude Flow.

## Available Commands

- [swarm-init](./swarm-init.md)
- [agent-spawn](./agent-spawn.md)
- [task-orchestrate](./task-orchestrate.md)
