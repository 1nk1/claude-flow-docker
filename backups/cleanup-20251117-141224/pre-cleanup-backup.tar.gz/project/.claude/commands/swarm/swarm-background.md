# swarm-background

Command documentation for swarm-background in category swarm.

Usage:
```bash
npx claude-flow swarm swarm-background [options]
```
