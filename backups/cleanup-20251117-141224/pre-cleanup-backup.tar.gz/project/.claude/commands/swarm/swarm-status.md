# swarm-status

Command documentation for swarm-status in category swarm.

Usage:
```bash
npx claude-flow swarm swarm-status [options]
```
