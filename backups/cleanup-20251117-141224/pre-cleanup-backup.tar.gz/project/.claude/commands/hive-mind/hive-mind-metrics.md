# hive-mind-metrics

Command documentation for hive-mind-metrics in category hive-mind.

Usage:
```bash
npx claude-flow hive-mind hive-mind-metrics [options]
```
