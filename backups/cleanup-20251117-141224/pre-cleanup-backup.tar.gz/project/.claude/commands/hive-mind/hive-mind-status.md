# hive-mind-status

Command documentation for hive-mind-status in category hive-mind.

Usage:
```bash
npx claude-flow hive-mind hive-mind-status [options]
```
