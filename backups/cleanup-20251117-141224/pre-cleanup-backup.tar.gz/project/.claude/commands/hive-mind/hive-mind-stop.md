# hive-mind-stop

Command documentation for hive-mind-stop in category hive-mind.

Usage:
```bash
npx claude-flow hive-mind hive-mind-stop [options]
```
