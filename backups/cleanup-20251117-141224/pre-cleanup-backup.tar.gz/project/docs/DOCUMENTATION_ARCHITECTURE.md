# Documentation Architecture Diagram

## Current State (Before Consolidation)

```
┌─────────────────────────────────────────────────────────────────┐
│                         ROOT LEVEL                               │
│                                                                   │
│  CLAUDE.md (352 lines - MONOLITHIC)                             │
│  ├── Critical Rules                                              │
│  ├── Setup Guide (DUPLICATE)                                     │
│  ├── Agent List (DUPLICATE)                                      │
│  ├── Command Reference (DUPLICATE)                               │
│  ├── Hooks Guide (DUPLICATE)                                     │
│  ├── Examples                                                     │
│  └── Support Links                                               │
└─────────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
│  .claude/        │ │  .hive-mind/     │ │  memory/         │
│                  │ │                  │ │                  │
│  ├── agents/     │ │  └── README.md   │ │  ├── agents/     │
│  │   (79 files)  │ │                  │ │  │   README.md   │
│  │               │ │                  │ │  └── sessions/   │
│  ├── commands/   │ │                  │ │      README.md   │
│  │   (150 files) │ │                  │ │                  │
│  │               │ │                  │ │                  │
│  └── helpers/    │ │                  │ │                  │
│      ├── quick-  │ │                  │ │                  │
│      │   start.sh│ │                  │ │                  │
│      └── setup-  │ │                  │ │                  │
│          mcp.sh  │ │                  │ │                  │
└──────────────────┘ └──────────────────┘ └──────────────────┘
```

### Problems Identified:
1. **🔴 CLAUDE.md is monolithic** (352 lines, mixes concerns)
2. **🔴 4 duplicate setup sources** (CLAUDE.md + 2 scripts + hooks/setup.md)
3. **🔴 3 duplicate hooks sources** (CLAUDE.md + hooks/setup.md + hooks/README.md)
4. **🔴 Fragmented navigation** (21 separate command directories)
5. **🔴 No clear entry point** for new users
6. **🔴 Agent list duplicated** (CLAUDE.md + 79 detailed files)

---

## Proposed State (After Consolidation)

```
┌─────────────────────────────────────────────────────────────────┐
│                    CLAUDE.md (REFACTORED)                        │
│                        ~150 lines max                            │
│                                                                   │
│  ┌─────────────────────────────────────────────────────┐        │
│  │  🚨 CRITICAL RULES ONLY                             │        │
│  │  - Concurrent execution patterns                     │        │
│  │  - File organization rules                           │        │
│  │  - Agent coordination protocol                       │        │
│  └─────────────────────────────────────────────────────┘        │
│                                                                   │
│  📚 DOCUMENTATION LINKS:                                         │
│     → Quick Start: docs/getting-started/QUICK_START.md          │
│     → Full Docs: docs/README.md                                 │
│     → Agents: docs/reference/AGENTS.md                          │
│     → Commands: docs/reference/COMMANDS.md                      │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      docs/ (NEW STRUCTURE)                       │
│                                                                   │
│  README.md (DOCUMENTATION HUB)                                   │
│  ├── Quick Navigation                                            │
│  ├── By Topic                                                    │
│  └── By Experience Level                                         │
│                                                                   │
│  ┌─────────────────┬──────────────┬──────────────┬────────────┐│
│  │ getting-started/│   guides/    │  reference/  │architecture/││
│  ├─────────────────┼──────────────┼──────────────┼────────────┤│
│  │ QUICK_START.md ⭐│ HOOKS_       │ AGENTS.md ⭐  │ SYSTEM_    ││
│  │ (CONSOLIDATED)  │   GUIDE.md ⭐ │ (CATALOG)    │   DESIGN.md││
│  │                 │              │              │            ││
│  │ INSTALLATION.md │ SPARC_       │ COMMANDS.md ⭐│ COORDI-    ││
│  │                 │   METHOD.md  │ (UNIFIED)    │   NATION.md││
│  │ FIRST_SWARM.md  │              │              │            ││
│  │                 │ SWARM_       │ MCP_TOOLS.md │ CONSENSUS. ││
│  │ COMMON_         │   PATTERNS.md│              │   md       ││
│  │   WORKFLOWS.md  │              │ API.md       │            ││
│  │                 │ MEMORY_      │              │ DATA_FLOW. ││
│  │                 │   SYSTEM.md  │ CONFIG.md    │   md       ││
│  │                 │              │              │            ││
│  │                 │ GITHUB_      │              │            ││
│  │                 │   INTEG.md   │              │            ││
│  │                 │              │              │            ││
│  │                 │ NEURAL_      │              │            ││
│  │                 │   FEATURES.md│              │            ││
│  └─────────────────┴──────────────┴──────────────┴────────────┘│
│                                                                   │
│  ┌─────────────────────────────────────────────────────┐        │
│  │                    advanced/                         │        │
│  │  ├── CUSTOM_AGENTS.md                               │        │
│  │  ├── PERFORMANCE_TUNING.md                          │        │
│  │  ├── TROUBLESHOOTING.md                             │        │
│  │  └── CONTRIBUTING.md                                │        │
│  └─────────────────────────────────────────────────────┘        │
│                                                                   │
│  ┌─────────────────────────────────────────────────────┐        │
│  │              SUPPORT FILES (NEW)                     │        │
│  │  ├── SEARCH_INDEX.md   (Full-text search)          │        │
│  │  ├── GLOSSARY.md       (Term definitions)           │        │
│  │  └── FAQ.md            (Common questions)           │        │
│  └─────────────────────────────────────────────────────┘        │
└─────────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
│  .claude/        │ │  .hive-mind/     │ │  memory/         │
│  (PRESERVED)     │ │  (PRESERVED)     │ │  (PRESERVED)     │
│                  │ │                  │ │                  │
│  ├── agents/     │ │  └── README.md   │ │  ├── agents/     │
│  │   (79 files)  │ │                  │ │  │   README.md   │
│  │   ↑           │ │                  │ │  └── sessions/   │
│  │   └──LINKED   │ │                  │ │      README.md   │
│  │      FROM     │ │                  │ │                  │
│  │      AGENTS.md│ │                  │ │                  │
│  │               │ │                  │ │                  │
│  ├── commands/   │ │                  │ │                  │
│  │   (150 files) │ │                  │ │                  │
│  │   ↑           │ │                  │ │                  │
│  │   └──LINKED   │ │                  │ │                  │
│  │      FROM     │ │                  │ │                  │
│  │      COMMANDS │ │                  │ │                  │
│  │      .md      │ │                  │ │                  │
│  │               │ │                  │ │                  │
│  └── helpers/    │ │                  │ │                  │
│      (ARCHIVE    │ │                  │ │                  │
│       old        │ │                  │ │                  │
│       scripts)   │ │                  │ │                  │
└──────────────────┘ └──────────────────┘ └──────────────────┘
```

---

## Information Flow Diagram

### Before (Fragmented):
```
User Request
    │
    ├─→ CLAUDE.md (352 lines)
    │      ├─→ Setup guide (incomplete)
    │      ├─→ Agent list (no details)
    │      └─→ Command ref (outdated)
    │
    ├─→ .claude/helpers/quick-start.sh
    │      └─→ Different workflow
    │
    ├─→ .claude/commands/hooks/setup.md
    │      └─→ Hooks-specific only
    │
    └─→ .claude/agents/* (79 files)
           └─→ No index, hard to discover
```

### After (Unified):
```
User Request
    │
    ├─→ CLAUDE.md (150 lines)
    │      ├─→ Critical rules ONLY
    │      └─→ Links to docs/
    │
    └─→ docs/README.md (HUB)
           │
           ├─→ getting-started/QUICK_START.md ⭐
           │      ├─→ MCP setup
           │      ├─→ First swarm
           │      └─→ Common workflows
           │
           ├─→ guides/HOOKS_GUIDE.md ⭐
           │      ├─→ Setup
           │      ├─→ Configuration
           │      └─→ Best practices
           │
           ├─→ reference/AGENTS.md ⭐
           │      ├─→ Agent catalog
           │      └─→ Links to .claude/agents/*
           │
           └─→ reference/COMMANDS.md ⭐
                  ├─→ Unified index
                  └─→ Links to .claude/commands/*
```

---

## Navigation Hierarchy

### Current (Depth: 5+ levels):
```
Root
└── CLAUDE.md
    └── (scroll to find topic)
        └── .claude/
            └── commands/
                └── category/
                    └── README.md
                        └── specific-command.md
```

### Proposed (Depth: 3 levels max):
```
Root
├── CLAUDE.md (critical rules + links)
│
└── docs/
    ├── README.md (hub)
    │
    ├── getting-started/
    │   └── QUICK_START.md (all setup consolidated)
    │
    ├── guides/
    │   ├── HOOKS_GUIDE.md (all hooks consolidated)
    │   └── [topic].md
    │
    └── reference/
        ├── AGENTS.md (catalog with links)
        └── COMMANDS.md (unified index)
```

---

## Cross-Reference Map

### Hub-and-Spoke Model:
```
                    docs/README.md
                    (Central Hub)
                          │
        ┌─────────────────┼─────────────────┐
        │                 │                 │
        ▼                 ▼                 ▼
  getting-started/    guides/          reference/
        │                 │                 │
        │                 │                 │
  ┌─────┴─────┐     ┌─────┴─────┐     ┌─────┴─────┐
  │           │     │           │     │           │
  ▼           ▼     ▼           ▼     ▼           ▼
QUICK_     FIRST_ HOOKS_    SPARC_  AGENTS    COMMANDS
START      SWARM  GUIDE     METHOD    .md        .md
  │           │     │           │       │          │
  │           │     │           │       │          │
  └───────────┴─────┴───────────┴───────┴──────────┘
              │                         │
              ▼                         ▼
       .claude/agents/*          .claude/commands/*
         (Detail Files)            (Detail Files)
```

### Bidirectional Linking:
- **From Guides → Reference**: "See [Agent Catalog](../reference/AGENTS.md)"
- **From Reference → Guides**: "Learn more in [Hooks Guide](../guides/HOOKS_GUIDE.md)"
- **From Catalog → Details**: "Detailed spec: [.claude/agents/core/coder.md](../../.claude/agents/core/coder.md)"

---

## Data Flow: User Journey

### Journey 1: New User
```
1. Read CLAUDE.md
   └─→ "New user? Start here: docs/getting-started/QUICK_START.md"

2. Follow QUICK_START.md
   ├─→ Install MCP (consolidated from 4 sources)
   ├─→ Run first swarm
   └─→ See results

3. Explore guides/
   └─→ Learn SPARC methodology
   └─→ Understand hooks system
```

### Journey 2: Find an Agent
```
1. Open docs/README.md
   └─→ Click "Agent Catalog"

2. Browse docs/reference/AGENTS.md
   ├─→ See categorized list
   └─→ Find "coder" agent

3. Click to detailed spec
   └─→ .claude/agents/core/coder.md
   └─→ See full configuration
```

### Journey 3: Learn a Command
```
1. Need to run a command
   └─→ Open docs/reference/COMMANDS.md

2. Search unified index
   └─→ Find "swarm init"

3. Click to detailed docs
   └─→ .claude/commands/swarm/swarm-init.md
   └─→ See syntax, examples, options
```

---

## Consolidation Impact

### Quantitative Improvements:
| Metric | Before | After | Change |
|--------|--------|-------|--------|
| Total MD files | 229 | ~100 | -56% |
| Setup sources | 4 | 1 | -75% |
| Hooks sources | 3 | 1 | -67% |
| CLAUDE.md lines | 352 | 150 | -57% |
| Nav depth | 5+ | 3 | -40% |
| Entry points | Multiple | 1 Hub | Unified |

### Qualitative Improvements:
- ✅ **Single source of truth** for each topic
- ✅ **Clear navigation** from hub
- ✅ **Progressive disclosure** (basic → advanced)
- ✅ **Better discoverability** (search, index, glossary)
- ✅ **Reduced maintenance** (fewer duplicates)
- ✅ **Improved onboarding** (guided paths)

---

## Migration Strategy Visualization

### Phase 1: Create Structure
```
mkdir -p docs/{getting-started,guides,reference,architecture,advanced}
```

### Phase 2: Consolidate (Week 2)
```
CLAUDE.md (setup) ─┐
setup-mcp.sh ──────┼─→ MERGE → docs/getting-started/QUICK_START.md
quick-start.sh ────┘

CLAUDE.md (hooks) ─┐
hooks/setup.md ────┼─→ MERGE → docs/guides/HOOKS_GUIDE.md
hooks/README.md ───┘ (keep as index)

CLAUDE.md (agents) ─→ EXTRACT → docs/reference/AGENTS.md
                                  └─→ LINK to .claude/agents/*

.claude/commands/* ─→ AGGREGATE → docs/reference/COMMANDS.md
                                   └─→ LINK to .claude/commands/*
```

### Phase 3: Refactor (Week 3)
```
CLAUDE.md (352 lines) ─→ SLIM DOWN → CLAUDE.md (150 lines)
                            │
                            ├─→ Keep: Critical rules
                            ├─→ Keep: Quick links
                            └─→ Remove: Duplicated content
```

### Phase 4: Validate (Week 4)
```
Automated Checks:
├─→ Link validator (scripts/validate_links.sh)
├─→ Content completeness check
├─→ Navigation flow test
└─→ User feedback collection
```

---

## Success Criteria

### User Experience:
- ✅ New user can start in < 5 minutes
- ✅ Any topic is ≤ 3 clicks away
- ✅ No duplicate or conflicting info
- ✅ Clear progression path (beginner → expert)

### Maintenance:
- ✅ Single update point per topic
- ✅ Automated link validation
- ✅ Version-controlled changes
- ✅ Clear ownership per section

### Discoverability:
- ✅ Search index for full-text search
- ✅ Glossary for term definitions
- ✅ FAQ for common questions
- ✅ Cross-references between related topics

---

**Architecture designed for clarity, maintainability, and user experience.**
