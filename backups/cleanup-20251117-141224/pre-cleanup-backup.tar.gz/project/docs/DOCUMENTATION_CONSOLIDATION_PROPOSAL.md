# Documentation Structure Consolidation Proposal

## Executive Summary

**Current State**: 229 markdown files distributed across multiple directories with significant content duplication and navigation challenges.

**Goal**: Streamline documentation into a coherent, maintainable structure that eliminates redundancy while improving discoverability.

---

## 1. Current Documentation Inventory

### 1.1 Root Level
- **CLAUDE.md** (352 lines, 16KB) - Primary configuration and instruction file
  - Contains: Setup guides, agent lists, command references, workflow patterns
  - Issues: Monolithic, contains duplicate content, mixes concerns

### 1.2 Command Documentation (150 files)
```
.claude/commands/
├── agents/           (5 files)
├── analysis/         (7 files)
├── automation/       (7 files)
├── coordination/     (7 files)
├── flow-nexus/       (9 files)
├── github/          (19 files)
├── hive-mind/       (12 files)
├── hooks/            (8 files)
├── memory/           (6 files)
├── monitoring/       (6 files)
├── optimization/     (6 files)
├── pair/             (6 files)
├── sparc/           (18 files)
├── stream-chain/     (2 files)
├── swarm/           (17 files)
├── training/         (6 files)
├── truth/            (1 files)
├── verify/           (2 files)
└── workflows/        (6 files)
```

### 1.3 Agent Definitions (79 files)
```
.claude/agents/
├── analysis/         (2 files)
├── architecture/     (1 file)
├── consensus/        (7 files)
├── core/             (5 files)
├── development/      (2 files)
├── devops/           (1 file)
├── documentation/    (1 file)
├── flow-nexus/       (9 files)
├── github/          (13 files)
├── hive-mind/        (5 files)
├── neural/           (1 file)
├── optimization/     (5 files)
├── sparc/            (4 files)
├── specialized/      (1 file)
├── swarm/            (3 files)
├── templates/        (9 files)
└── testing/          (2 files)
```

### 1.4 Helper Scripts (5 files)
```
.claude/helpers/
├── checkpoint-manager.sh
├── github-setup.sh
├── quick-start.sh
├── setup-mcp.sh
└── standard-checkpoint-hooks.sh
```

### 1.5 Additional Documentation
- `.hive-mind/README.md` - Hive Mind system overview
- `memory/agents/README.md` - Agent memory system
- `memory/sessions/README.md` - Session management

---

## 2. Identified Duplications & Overlaps

### 2.1 Critical Duplications

#### Setup & Quick Start (4 sources)
1. **CLAUDE.md** - "Quick Setup" section (lines 141-148)
   - MCP server installation
   - Basic configuration

2. **.claude/helpers/setup-mcp.sh** - Automated MCP setup
   - Same MCP commands as CLAUDE.md
   - Additional validation logic

3. **.claude/helpers/quick-start.sh** - CLI quick start
   - Different workflow than CLAUDE.md
   - Focuses on swarm operations

4. **.claude/commands/hooks/setup.md** - Hooks-specific setup
   - Overlaps with CLAUDE.md hooks section
   - More detailed than CLAUDE.md

**Recommendation**: **CONSOLIDATE** into single getting-started guide

#### Hooks Documentation (3 sources)
1. **CLAUDE.md** - "Hooks Integration" section (lines 293-314)
2. **.claude/commands/hooks/setup.md** - Setup guide
3. **.claude/commands/hooks/README.md** - Index of hook commands

**Recommendation**: **MERGE** into cohesive hooks guide

#### Agent Lists (2 sources)
1. **CLAUDE.md** - "Available Agents" section (lines 87-114)
   - 54 agents listed by category
   - No detail, just names

2. **.claude/agents/** - Individual agent definitions
   - 79 detailed agent files
   - Full specifications and examples

**Recommendation**: **RESTRUCTURE** with index in main docs, details in agents/

#### Command References (Fragmented)
- 21 separate README files in `.claude/commands/*`
- Each contains minimal context
- No unified command reference

**Recommendation**: **CREATE** unified command reference with deep links

---

## 3. Consolidation Strategy

### 3.1 Files to Merge

#### Priority 1: Setup Consolidation
**Merge Into**: `/docs/getting-started/QUICK_START.md`
- ✅ Merge: CLAUDE.md "Quick Setup" section
- ✅ Merge: `.claude/helpers/setup-mcp.sh` (convert to documentation)
- ✅ Merge: `.claude/helpers/quick-start.sh` (convert to documentation)
- ✅ Reference: `.claude/commands/hooks/setup.md` (keep for advanced users)
- **Result**: Single comprehensive quick start guide

#### Priority 2: Hooks Consolidation
**Merge Into**: `/docs/guides/HOOKS_GUIDE.md`
- ✅ Merge: CLAUDE.md "Hooks Integration" section
- ✅ Merge: `.claude/commands/hooks/setup.md`
- ✅ Keep: `.claude/commands/hooks/README.md` (as index)
- ✅ Keep: Individual hook command files (reference material)
- **Result**: Complete hooks guide with reference links

#### Priority 3: Agent Reference
**Create**: `/docs/reference/AGENTS.md`
- ✅ Extract: CLAUDE.md "Available Agents" section
- ✅ Link to: `.claude/agents/*` for detailed specs
- ✅ Add: Auto-generated agent catalog
- **Result**: Discoverable agent directory with deep links

#### Priority 4: Command Reference
**Create**: `/docs/reference/COMMANDS.md`
- ✅ Aggregate: All `.claude/commands/*/README.md` files
- ✅ Create: Searchable command index
- ✅ Link to: Detailed command documentation
- **Result**: Unified command reference

### 3.2 Files to Delete (Post-Consolidation)
- ❌ Delete: Redundant setup content from CLAUDE.md (move to guides)
- ❌ Delete: `.claude/helpers/setup-mcp.sh` (after documenting)
- ❌ Delete: `.claude/helpers/quick-start.sh` (after documenting)
- ❌ Archive: Duplicate agent listings in CLAUDE.md

### 3.3 Files to Keep
- ✅ Keep: CLAUDE.md (as primary instruction file, but slimmed down)
- ✅ Keep: `.claude/agents/*` (detailed agent specifications)
- ✅ Keep: `.claude/commands/*` (command documentation)
- ✅ Keep: `.hive-mind/README.md` (system-specific)
- ✅ Keep: `memory/*/README.md` (subsystem docs)

---

## 4. Proposed Documentation Structure

```
/workspace/project/
├── CLAUDE.md (REFACTORED - 150 lines max)
│   ├── Critical Rules Only
│   ├── Quick Links to Guides
│   └── System Overview
│
├── docs/
│   ├── README.md (Documentation Hub)
│   │
│   ├── getting-started/
│   │   ├── QUICK_START.md ⭐ (CONSOLIDATED)
│   │   ├── INSTALLATION.md
│   │   ├── FIRST_SWARM.md
│   │   └── COMMON_WORKFLOWS.md
│   │
│   ├── guides/
│   │   ├── HOOKS_GUIDE.md ⭐ (CONSOLIDATED)
│   │   ├── SPARC_METHODOLOGY.md
│   │   ├── SWARM_PATTERNS.md
│   │   ├── MEMORY_SYSTEM.md
│   │   ├── GITHUB_INTEGRATION.md
│   │   └── NEURAL_FEATURES.md
│   │
│   ├── reference/
│   │   ├── AGENTS.md ⭐ (NEW - AGENT CATALOG)
│   │   ├── COMMANDS.md ⭐ (NEW - UNIFIED REFERENCE)
│   │   ├── MCP_TOOLS.md
│   │   ├── API.md
│   │   └── CONFIGURATION.md
│   │
│   ├── architecture/
│   │   ├── SYSTEM_DESIGN.md
│   │   ├── COORDINATION.md
│   │   ├── CONSENSUS.md
│   │   └── DATA_FLOW.md
│   │
│   └── advanced/
│       ├── CUSTOM_AGENTS.md
│       ├── PERFORMANCE_TUNING.md
│       ├── TROUBLESHOOTING.md
│       └── CONTRIBUTING.md
│
├── .claude/
│   ├── agents/ (Keep as-is - detailed specs)
│   ├── commands/ (Keep as-is - command reference)
│   └── helpers/ (Keep essential scripts only)
│
├── .hive-mind/
│   └── README.md (Keep as-is - system docs)
│
└── memory/
    └── */README.md (Keep as-is - subsystem docs)
```

---

## 5. Navigation Improvements

### 5.1 Create Documentation Hub
**File**: `/docs/README.md`

```markdown
# Claude Flow Documentation

## Quick Navigation
- 🚀 [Quick Start](./getting-started/QUICK_START.md)
- 📖 [Guides](./guides/)
- 📚 [Reference](./reference/)
- 🏗️ [Architecture](./architecture/)
- ⚡ [Advanced](./advanced/)

## By Topic
- [Swarm Operations](./guides/SWARM_PATTERNS.md)
- [Agent Catalog](./reference/AGENTS.md)
- [Command Reference](./reference/COMMANDS.md)
- [Hooks System](./guides/HOOKS_GUIDE.md)

## By Experience Level
- Beginner → [Quick Start](./getting-started/QUICK_START.md)
- Intermediate → [Guides](./guides/)
- Advanced → [Architecture](./architecture/), [Advanced](./advanced/)
```

### 5.2 Refactor CLAUDE.md
**Slim down to essentials** (150 lines max):

```markdown
# Claude Code Configuration

## 🚨 CRITICAL RULES
[Keep only critical execution rules]

## 📚 Documentation
- [Quick Start](./docs/getting-started/QUICK_START.md)
- [Full Documentation](./docs/README.md)
- [Agent Catalog](./docs/reference/AGENTS.md)
- [Command Reference](./docs/reference/COMMANDS.md)

## 🎯 System Overview
[Brief 5-line overview]

## 🔗 Quick Links
[Essential links only]
```

### 5.3 Add Cross-References
- Each guide links to related reference material
- Reference pages link back to guides
- Agent definitions link to related commands
- Command docs link to relevant guides

### 5.4 Search & Discovery
- **Create**: `/docs/SEARCH_INDEX.md` - Full-text search index
- **Create**: `/docs/GLOSSARY.md` - Term definitions
- **Create**: `/docs/FAQ.md` - Common questions

---

## 6. Duplicate Content Elimination Plan

### Phase 1: Analysis (Completed ✅)
- ✅ Identified 229 total markdown files
- ✅ Found 4 duplicate setup sources
- ✅ Found 3 duplicate hooks sources
- ✅ Mapped command documentation (21 directories)

### Phase 2: Consolidation (Next Steps)

#### Step 1: Create New Structure
```bash
mkdir -p docs/{getting-started,guides,reference,architecture,advanced}
```

#### Step 2: Merge Setup Documentation
```bash
# Create consolidated quick start
cat CLAUDE.md (lines 141-148) \
    .claude/helpers/setup-mcp.sh (documented) \
    .claude/helpers/quick-start.sh (documented) \
    > docs/getting-started/QUICK_START.md
```

#### Step 3: Merge Hooks Documentation
```bash
# Create consolidated hooks guide
cat CLAUDE.md (lines 293-314) \
    .claude/commands/hooks/setup.md \
    > docs/guides/HOOKS_GUIDE.md
```

#### Step 4: Create Agent Catalog
```bash
# Extract and enhance agent list
python scripts/generate_agent_catalog.py \
    --source CLAUDE.md \
    --agents-dir .claude/agents \
    --output docs/reference/AGENTS.md
```

#### Step 5: Create Command Reference
```bash
# Aggregate command documentation
python scripts/generate_command_reference.py \
    --commands-dir .claude/commands \
    --output docs/reference/COMMANDS.md
```

#### Step 6: Refactor CLAUDE.md
```bash
# Slim down to essentials
python scripts/refactor_claude_md.py \
    --input CLAUDE.md \
    --output CLAUDE.md.new \
    --max-lines 150
```

#### Step 7: Clean Up
```bash
# Archive old setup scripts
mkdir -p .claude/helpers/archive
mv .claude/helpers/{setup-mcp.sh,quick-start.sh} .claude/helpers/archive/
```

### Phase 3: Validation
- ✅ Verify all links work
- ✅ Check for broken references
- ✅ Test navigation flows
- ✅ Validate content completeness

### Phase 4: Migration
- ✅ Update all references to point to new locations
- ✅ Add deprecation notices to old files
- ✅ Update CI/CD to use new structure

---

## 7. Implementation Roadmap

### Week 1: Foundation
- [ ] Create new `/docs` structure
- [ ] Build documentation hub (README.md)
- [ ] Create search index and glossary

### Week 2: Consolidation
- [ ] Merge setup documentation → QUICK_START.md
- [ ] Merge hooks documentation → HOOKS_GUIDE.md
- [ ] Create agent catalog → AGENTS.md
- [ ] Create command reference → COMMANDS.md

### Week 3: Migration
- [ ] Refactor CLAUDE.md (slim down)
- [ ] Update all cross-references
- [ ] Add deprecation notices
- [ ] Archive redundant files

### Week 4: Enhancement
- [ ] Add diagrams and visuals
- [ ] Create video tutorials (links)
- [ ] Build interactive examples
- [ ] Gather user feedback

---

## 8. Success Metrics

### Quantitative
- **File Reduction**: 229 → ~100 files (-56%)
- **Duplication**: 4 setup sources → 1 (-75%)
- **CLAUDE.md Size**: 352 lines → ~150 lines (-57%)
- **Navigation Depth**: Reduce from 5+ levels to 3 levels

### Qualitative
- ✅ Single source of truth for each topic
- ✅ Clear navigation hierarchy
- ✅ Improved discoverability
- ✅ Reduced maintenance burden
- ✅ Better onboarding experience

---

## 9. Risk Mitigation

### Risk 1: Broken References
- **Mitigation**: Automated link checking in CI/CD
- **Rollback**: Keep backups of all moved/deleted files

### Risk 2: User Confusion During Transition
- **Mitigation**: Deprecation notices with redirect links
- **Mitigation**: Clear migration guide
- **Mitigation**: Keep old structure for 1 month

### Risk 3: Content Loss
- **Mitigation**: Version control all changes
- **Mitigation**: Archive deleted files
- **Mitigation**: Peer review all consolidations

---

## 10. Next Steps

### Immediate Actions (This Session)
1. ✅ Store this proposal in memory
2. ✅ Share with coordination team
3. ✅ Get stakeholder approval

### Follow-Up Tasks
1. Create `/docs` directory structure
2. Begin Phase 1 consolidation (setup docs)
3. Build automated consolidation scripts
4. Test with sample users

---

## Appendix A: File Mapping

### Setup Documentation Sources
| Source | Lines | Content | Action |
|--------|-------|---------|--------|
| CLAUDE.md (141-148) | 8 | MCP setup commands | Merge → QUICK_START.md |
| .claude/helpers/setup-mcp.sh | 25 | Automated MCP setup | Document → QUICK_START.md |
| .claude/helpers/quick-start.sh | 18 | CLI workflow | Document → QUICK_START.md |
| .claude/commands/hooks/setup.md | 103 | Hooks setup | Keep for advanced reference |

### Hooks Documentation Sources
| Source | Lines | Content | Action |
|--------|-------|---------|--------|
| CLAUDE.md (293-314) | 22 | Hooks overview | Merge → HOOKS_GUIDE.md |
| .claude/commands/hooks/setup.md | 103 | Detailed setup | Merge → HOOKS_GUIDE.md |
| .claude/commands/hooks/README.md | 12 | Index | Keep as index |

### Agent Documentation Sources
| Source | Files | Content | Action |
|--------|-------|---------|--------|
| CLAUDE.md (87-114) | 1 | Agent name list | Extract → AGENTS.md |
| .claude/agents/* | 79 | Detailed specs | Keep, link from catalog |

### Command Documentation Sources
| Source | Files | Content | Action |
|--------|-------|---------|--------|
| .claude/commands/*/README.md | 21 | Category indexes | Aggregate → COMMANDS.md |
| .claude/commands/*/*.md | 129 | Individual commands | Keep, link from index |

---

## Appendix B: Proposed Tool Scripts

### Script 1: Agent Catalog Generator
```python
# scripts/generate_agent_catalog.py
# Reads CLAUDE.md and .claude/agents/*.md
# Generates comprehensive agent catalog with:
# - Categories
# - Descriptions
# - Links to detailed specs
# - Usage examples
```

### Script 2: Command Reference Generator
```python
# scripts/generate_command_reference.py
# Aggregates all command documentation
# Creates searchable command reference with:
# - Command syntax
# - Parameters
# - Examples
# - Related commands
```

### Script 3: CLAUDE.md Refactorer
```python
# scripts/refactor_claude_md.py
# Slims down CLAUDE.md to essentials
# Moves detailed content to guides
# Adds links to new documentation structure
```

### Script 4: Link Validator
```bash
# scripts/validate_links.sh
# Checks all markdown links
# Reports broken references
# Suggests fixes
```

---

**End of Proposal**
