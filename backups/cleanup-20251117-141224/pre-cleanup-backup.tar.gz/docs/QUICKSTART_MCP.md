# 🚀 Quick Start: MCP Connection in 3 Minutes

Get Claude Code connected to claude-flow in Docker in just 3 minutes!

## Step 1: Start Docker Container (30 seconds)

```bash
cd /path/to/claude-flow-docker
make start
```

Or without make:
```bash
docker-compose up -d
```

**Verify it's running:**
```bash
docker ps | grep claude-flow-alpha
```

## Step 2: Connect Your Project (30 seconds)

### Option A: Automatic Setup (Recommended)

```bash
./connect-mcp.sh ~/projects/your-project
```

### Option B: Manual Setup

```bash
cd ~/projects/your-project
mkdir -p .claude
cp /path/to/claude-flow-docker/config/.claude/settings.json ./.claude/
```

## Step 3: Test Connection (30 seconds)

```bash
cd ~/projects/your-project
claude
```

In Claude Code, ask:
```
Show me the claude-flow swarm status using MCP
```

## ✅ Success Indicators

You should see:
- ✅ Claude Code starts without errors
- ✅ MCP server "claude-flow" shows as connected
- ✅ 87 MCP tools available
- ✅ Claude can create swarms and spawn agents

## 🎯 First Commands to Try

1. **Create a swarm:**
   ```
   Create a mesh swarm with 3 agents: researcher, coder, and tester
   ```

2. **Check status:**
   ```
   Show me the swarm status and list all active agents
   ```

3. **Use memory:**
   ```
   Store "project_name: awesome-app" in memory
   ```

4. **Neural network:**
   ```
   Show neural network status
   ```

## 🔧 Troubleshooting

### Container not running?
```bash
docker-compose up -d
```

### MCP not connecting?
```bash
# Check container
docker ps | grep claude-flow

# Check logs
docker logs claude-flow-alpha --tail 20

# Restart
docker restart claude-flow-alpha
```

### Still not working?
See [Full MCP Connection Guide](MCP_CONNECTION.md) for detailed troubleshooting.

## 📚 Next Steps

- [Full MCP Documentation](MCP_CONNECTION.md)
- [Available MCP Tools](MCP_CONNECTION.md#available-mcp-tools-87-total)
- [Advanced Configuration](MCP_CONNECTION.md#advanced-configuration)
- [Troubleshooting Guide](../TROUBLESHOOTING.md)

---

**That's it! You're ready to use claude-flow MCP! 🎉**
