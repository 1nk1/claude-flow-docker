# Quick Reference - Claude-Flow Docker v2.0

## 📋 All New Logging Commands

```bash
make logs-app          # Follow application logs (real-time)
make logs-app-tail     # Last 100 lines of app logs
make logs-error        # Search for errors
make logs-warn         # Search for warnings
make logs-mcp          # View MCP events only
make logs-stats        # Log statistics
make logs-viewer       # Interactive log viewer (recommended)
```

## 🔧 Environment Variables

Add to `.env`:
```bash
LOG_LEVEL=INFO                           # TRACE|DEBUG|INFO|SUCCESS|WARN|ERROR|FATAL
LOG_TO_FILE=true                         # Enable file logging
LOG_FILE=/workspace/logs/claude-flow.log # Log file path
MCP_SERVER_MODE=stdio                    # Changed from tcp
```

## 📊 Log Levels

| Level | When to Use |
|-------|------------|
| TRACE | Extreme debugging (npm output, commands) |
| DEBUG | Development, troubleshooting |
| INFO | Normal operations (default) |
| SUCCESS | Confirmations |
| WARN | Non-critical issues |
| ERROR | Failures |
| FATAL | Critical errors (exits) |

## 🎯 Common Tasks

### View Logs
```bash
make logs-viewer       # Interactive (best)
make logs-app          # Real-time
make logs-app-tail     # Last 100 lines
```

### Debug Issues
```bash
make logs-error        # Find errors
make logs-warn         # Find warnings
make logs-stats        # Statistics
```

### Change Log Level
```bash
# Temporary
LOG_LEVEL=DEBUG make start

# Permanent
echo "LOG_LEVEL=DEBUG" >> .env
make restart
```

## 🚀 Quick Start

### New Installation
```bash
git clone <repo>
cd claude-flow-docker
make setup
vim .env  # Configure PROJECT_PATH, ANTHROPIC_API_KEY
make build && make start
make logs-viewer
```

### Upgrade Existing
```bash
make backup
cat >> .env << 'EOF'
LOG_LEVEL=INFO
LOG_TO_FILE=true
LOG_FILE=/workspace/logs/claude-flow.log
EOF
make clean && make build && make start
make logs-stats
```

## 🆘 Troubleshooting

```bash
# Container won't start
docker logs claude-flow-alpha

# No logs appearing
docker exec claude-flow-alpha ls -la /workspace/logs/
make restart

# MCP not connected
./connect-mcp.sh ~/your-project
claude mcp list

# Log file too large
docker exec claude-flow-alpha bash -c "source /workspace/lib/logger.sh && log_rotate 10"
```

## 📖 Documentation Map

| Doc | Purpose | Time |
|-----|---------|------|
| START_HERE.md | Quick start | 2 min |
| README.md | Main docs | 5 min |
| DEPLOYMENT.md | Deploy/upgrade | 10 min |
| LOGGING.md | Logging system | 15 min |
| CHANGES_SUMMARY.md | What changed | 5 min |
| CLEANUP_GUIDE.md | Cleanup details | 5 min |

## 💡 Pro Tips

1. Use interactive viewer: `make logs-viewer`
2. Follow logs while working: `make logs-app`
3. Debug with verbose: `LOG_LEVEL=DEBUG make start`
4. Export for analysis: `make logs-save`
5. Monitor MCP: `make logs-mcp`

---

**Version:** 2.0.0 | **Updated:** November 17, 2025
